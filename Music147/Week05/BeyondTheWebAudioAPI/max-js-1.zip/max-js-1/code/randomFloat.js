inlets = 1;
outlets = 1;

function bang() {
  var random = Math.random();
  outlet(0, random);
}