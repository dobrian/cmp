inlets = 1;
outlets = 1;

function bang() {
  post("hello world\n");
}