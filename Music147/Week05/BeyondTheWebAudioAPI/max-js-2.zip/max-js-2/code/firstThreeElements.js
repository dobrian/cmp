outlets = 3;

function msg_int(i, j, k) {
  outlet(0, i);
  outlet(1, j);
  outlet(2, k);
}