function msg_int(i) {
  outlet(0, i + 5);
}

function msg_float(f) {
  outlet(0, f + 5);
}